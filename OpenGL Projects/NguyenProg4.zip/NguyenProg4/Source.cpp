// CS 445 Prog 4 for Anhkhoa Nguyen
// EXTRA CREDIT: Green lights on fan

// Architecture Statement:
// This program is a game that has the user control a fish to collect food. All objects (including the text) are drawn through display_func. Animation of both the fish
// and fan are controlled by timer_func which then calls the display_func every iteration of itself. timer_func also calls itself every 80msec in order to achieve roughly
// 12.5 frames per second in animation. The food's visual and behaviors are controlled by it's own dedicated function called "food". Keyboard inputs are read and handled through
// keyboard_func in order to reposition the fish respective to the key inputted. Camera settings were modified OpenGL445Setup.h to achieve an angular side view of the scene.

#include "pch.h"
#include <GL/glew.h>
#include <GL/freeglut.h> 
#include "OpenGL445Setup.h"
#include <stdio.h>

#define _USE_MATH_DEFINES
#include <math.h>

int score = 0;
int fanRotatePos = -1;	// used in the rotation animation of the fan
float bladeScale = 50.0;
float fishx = 0;
float fishy = 0;
float foodx = (rand() % 200) - 100;	// range = [-100, 100]
float foody = (rand() % 200) - 100;	// so we subtract 100 from range [0, 200]
int visible = 1;	// variable to toggle food color from white to black (visible or invisible), starts white (visible)
int foodLifetime = 0;	// used for tracking elapsed frames to calculate time passed of food being uneaten
int distance;	// used to measure distance between fish and food
int timer = 30;	// seconds remaining
int elapsedFrames = 0;	// used to measure passing time for the timer by dividing this variable by 12 to get seconds
bool gameOver = false;

void food();	// spawn food func proto

void display_func()
{
	// display callback (footnote: automatically invoked after GLUT finds that a window needs to be
	// displayed or  redisplayed

	// black background, clear the canvas every time display_func is called
	glClearColor(0.0, 0.0, 0.0, 1.0);
	glClear(GL_COLOR_BUFFER_BIT);

	// score tracker
	// concatenate string text with score counter into one string to be printed using bitmap representation
	char scoreBuffer[10];	// buffer to store "Score: xyz\n"
	snprintf(scoreBuffer, 10, "Score: %d", score);	// puts score string into buffer
	glColor3f(1.0, 1.0, 1.0);
	glLoadIdentity();
	glRasterPos3f(-340, 260, -50);
	glutBitmapString(GLUT_BITMAP_8_BY_13, (UCHAR*)scoreBuffer);	// writed concatenated string
	// timer
	// concatenate string text with score counter into one string to be printed using bitmap representation
	char timeBuffer[19];	// buffer to store "Score: xyz\n"
	snprintf(timeBuffer, 19, "Time Remaining: %d", timer);	// puts score string into buffer
	glColor3f(1.0, 1.0, 1.0);
	glLoadIdentity();
	glRasterPos3f(150, 360, -50);
	glutBitmapString(GLUT_BITMAP_8_BY_13, (UCHAR*)timeBuffer);	// writed concatenated string

	// game over text
	if (gameOver)
	{
		glRasterPos3f(-80, -260, -50);
		glutBitmapString(GLUT_BITMAP_8_BY_13, (UCHAR*)"GAME OVER");
	}

	// draw fan
	glMatrixMode(GL_MODELVIEW);		// specify model view matrix
	glLoadIdentity();				// ensures fresh states
	glColor3f(0.5, 0.5, 0);			// dull yellow
	// blades
	// 12 blades total, every other is yellow (visible) and the rest are black (empty)
	glRotatef(fanRotatePos*7.2, 0, 0, 1);			// rotate 7.2 degrees about the z axis every frame update
	glBegin(GL_TRIANGLES);
	/* =================================================
						format
		glVertex3f(center);
		glVertex3f(50*vert1x, 50*vert1y, -300.0);
		glVertex3f(50*vert2x, 50*vert2y, -300.0);
	====================================================*/
	// 0
	glColor3f(0.5, 0.5, 0);			// dull yellow
	glVertex3f(0.0, 0.0, -300.0);
	glVertex3f(bladeScale*cos(0), bladeScale*sin(0), -300.0);
	glVertex3f(bladeScale*cos(M_PI / 6), bladeScale*sin(M_PI / 6), -300.0);
	// 30
	glColor3f(0, 0, 0);				// black (empty)
	glVertex3f(0.0, 0.0, -300.0);
	glVertex3f(bladeScale*cos(M_PI / 6), bladeScale*sin(M_PI / 6), -300.0);
	glVertex3f(bladeScale*cos(M_PI / 3), bladeScale*sin(M_PI / 3), -300.0);
	// 60
	glColor3f(0.5, 0.5, 0);			// dull yellow
	glVertex3f(0.0, 0.0, -300.0);
	glVertex3f(bladeScale*cos(M_PI / 3), bladeScale*sin(M_PI / 3), -300.0);
	glVertex3f(bladeScale*cos(M_PI / 2), bladeScale*sin(M_PI / 2), -300.0);
	// 90
	glColor3f(0, 0, 0);				// black (empty)
	glVertex3f(0.0, 0.0, -300.0);
	glVertex3f(bladeScale*cos(M_PI / 2), bladeScale*sin(M_PI / 2), -300.0);
	glVertex3f(bladeScale*cos((2*M_PI) / 3), bladeScale*sin((2*M_PI) / 3), -300.0);
	// 120
	glColor3f(0.5, 0.5, 0);			// dull yellow
	glVertex3f(0.0, 0.0, -300.0);
	glVertex3f(bladeScale*cos((2 * M_PI) / 3), bladeScale*sin((2 * M_PI) / 3), -300.0);
	glVertex3f(bladeScale*cos((5 * M_PI) / 6), bladeScale*sin((5 * M_PI) / 6), -300.0);
	// 150
	glColor3f(0, 0, 0);				// black (empty)
	glVertex3f(0.0, 0.0, -300.0);
	glVertex3f(bladeScale*cos((5 * M_PI) / 6), bladeScale*sin((5 * M_PI) / 6), -300.0);
	glVertex3f(bladeScale*cos(M_PI), bladeScale*sin(M_PI), -300.0);
	// 180
	glColor3f(0.5, 0.5, 0);			// dull yellow
	glVertex3f(0.0, 0.0, -300.0);
	glVertex3f(bladeScale*cos(M_PI), bladeScale*sin(M_PI), -300.0);
	glVertex3f(bladeScale*cos((7 * M_PI) / 6), bladeScale*sin((7 * M_PI) / 6), -300.0);
	// 210
	glColor3f(0, 0, 0);				// black (empty)
	glVertex3f(0.0, 0.0, -300.0);
	glVertex3f(bladeScale*cos((7 * M_PI) / 6), bladeScale*sin((7 * M_PI) / 6), -300.0);
	glVertex3f(bladeScale*cos((4 * M_PI) / 3), bladeScale*sin((4 * M_PI) / 3), -300.0);
	// 240
	glColor3f(0.5, 0.5, 0);			// dull yellow
	glVertex3f(0.0, 0.0, -300.0);
	glVertex3f(bladeScale*cos((4 * M_PI) / 3), bladeScale*sin((4 * M_PI) / 3), -300.0);
	glVertex3f(bladeScale*cos((3 * M_PI) / 2), bladeScale*sin((3 * M_PI) / 2), -300.0);
	// 270
	glColor3f(0, 0, 0);				// black (empty)
	glVertex3f(0.0, 0.0, -300.0);
	glVertex3f(bladeScale*cos((3 * M_PI) / 2), bladeScale*sin((3 * M_PI) / 2), -300.0);
	glVertex3f(bladeScale*cos((5 * M_PI) / 3), bladeScale*sin((5 * M_PI) / 3), -300.0);
	// 300
	glColor3f(0.5, 0.5, 0);			// dull yellow
	glVertex3f(0.0, 0.0, -300.0);
	glVertex3f(bladeScale*cos((5 * M_PI) / 3), bladeScale*sin((5 * M_PI) / 3), -300.0);
	glVertex3f(bladeScale*cos((11 * M_PI) / 6), bladeScale*sin((11 * M_PI) / 6), -300.0);
	// 330
	glColor3f(0, 0, 0);				// black (empty)
	glVertex3f(0.0, 0.0, -300.0);
	glVertex3f(bladeScale*cos((11 * M_PI) / 6), bladeScale*sin((11 * M_PI) / 6), -300.0);
	glVertex3f(bladeScale*cos(0), bladeScale*sin(0), -300.0);
	glEnd();

	// fan lights
	// same format as the fan blades
	// except we multiply points by 20, 30, 40 respectively to disperse green lights alone the fan blades
	// at radius= 20, 30, and 40
	glMatrixMode(GL_MODELVIEW);		// specify model view matrix
	glLoadIdentity();				// ensures fresh states
	glRotatef(fanRotatePos*7.2, 0, 0, 1);			// sync up with the actual blades
	glColor3f(0.0, 1.0, 0.2);	// bright green
	glBegin(GL_LINES);

	// 0
	glVertex3f(19*cos(0), 19*sin(0), -300.0);
	glVertex3f(20*cos(0), 20*sin(0), -300.0);
	glVertex3f(29*cos(0), 29*sin(0), -300.0);
	glVertex3f(30*cos(0), 30*sin(0), -300.0);
	glVertex3f(39*cos(0), 39*sin(0), -300.0);
	glVertex3f(40*cos(0), 40*sin(0), -300.0);
	// 30
	glVertex3f(19*cos(M_PI / 6), 19*sin(M_PI / 6), -300.0);
	glVertex3f(20*cos(M_PI / 6), 20*sin(M_PI / 6), -300.0);
	glVertex3f(29*cos(M_PI / 6), 29*sin(M_PI / 6), -300.0);
	glVertex3f(30*cos(M_PI / 6), 30*sin(M_PI / 6), -300.0);
	glVertex3f(39*cos(M_PI / 6), 39*sin(M_PI / 6), -300.0);
	glVertex3f(40*cos(M_PI / 6), 40*sin(M_PI / 6), -300.0);
	// 60
	glVertex3f(19 *cos(M_PI / 3), 19 *sin(M_PI / 3), -300.0);
	glVertex3f(20 *cos(M_PI / 3), 20 *sin(M_PI / 3), -300.0);
	glVertex3f(29 *cos(M_PI / 3), 29 *sin(M_PI / 3), -300.0);
	glVertex3f(30 *cos(M_PI / 3), 30 *sin(M_PI / 3), -300.0);
	glVertex3f(39 *cos(M_PI / 3), 39 *sin(M_PI / 3), -300.0);
	glVertex3f(40 *cos(M_PI / 3), 40 *sin(M_PI / 3), -300.0);
	// 90
	glVertex3f(19 *cos(M_PI / 2), 19 *sin(M_PI / 2), -300.0);
	glVertex3f(20 *cos(M_PI / 2), 20 *sin(M_PI / 2), -300.0);
	glVertex3f(29 *cos(M_PI / 2), 29 *sin(M_PI / 2), -300.0);
	glVertex3f(30 *cos(M_PI / 2), 30 *sin(M_PI / 2), -300.0);
	glVertex3f(39 *cos(M_PI / 2), 39 *sin(M_PI / 2), -300.0);
	glVertex3f(40 *cos(M_PI / 2), 40 *sin(M_PI / 2), -300.0);
	// 120
	glVertex3f(19 *cos((2 * M_PI) / 3), 19 *sin((2 * M_PI) / 3), -300.0);
	glVertex3f(20 *cos((2 * M_PI) / 3), 20 *sin((2 * M_PI) / 3), -300.0);
	glVertex3f(29 *cos((2 * M_PI) / 3), 29 *sin((2 * M_PI) / 3), -300.0);
	glVertex3f(30 *cos((2 * M_PI) / 3), 30 *sin((2 * M_PI) / 3), -300.0);
	glVertex3f(39 *cos((2 * M_PI) / 3), 39 *sin((2 * M_PI) / 3), -300.0);
	glVertex3f(40 *cos((2 * M_PI) / 3), 40 *sin((2 * M_PI) / 3), -300.0);
	// 150
	glVertex3f(19 *cos((5 * M_PI) / 6), 19 *sin((5 * M_PI) / 6), -300.0);
	glVertex3f(20 *cos((5 * M_PI) / 6), 20 *sin((5 * M_PI) / 6), -300.0);
	glVertex3f(29 *cos((5 * M_PI) / 6), 29 *sin((5 * M_PI) / 6), -300.0);
	glVertex3f(30 *cos((5 * M_PI) / 6), 30 *sin((5 * M_PI) / 6), -300.0);
	glVertex3f(39 *cos((5 * M_PI) / 6), 39 *sin((5 * M_PI) / 6), -300.0);
	glVertex3f(40 *cos((5 * M_PI) / 6), 40 *sin((5 * M_PI) / 6), -300.0);
	// 180
	glVertex3f(19 *cos(M_PI), 19 *sin(M_PI), -300.0);
	glVertex3f(20 *cos(M_PI), 20 *sin(M_PI), -300.0);
	glVertex3f(29 *cos(M_PI), 29 *sin(M_PI), -300.0);
	glVertex3f(30 *cos(M_PI), 30 *sin(M_PI), -300.0);
	glVertex3f(39 *cos(M_PI), 39 *sin(M_PI), -300.0);
	glVertex3f(40 *cos(M_PI), 40 *sin(M_PI), -300.0);
	// 210
	glVertex3f(19 *cos((7 * M_PI) / 6), 19 *sin((7 * M_PI) / 6), -300.0);
	glVertex3f(20 *cos((7 * M_PI) / 6), 20 *sin((7 * M_PI) / 6), -300.0);
	glVertex3f(29 *cos((7 * M_PI) / 6), 29 *sin((7 * M_PI) / 6), -300.0);
	glVertex3f(30 *cos((7 * M_PI) / 6), 30 *sin((7 * M_PI) / 6), -300.0);
	glVertex3f(39 *cos((7 * M_PI) / 6), 39 *sin((7 * M_PI) / 6), -300.0);
	glVertex3f(40 *cos((7 * M_PI) / 6), 40 *sin((7 * M_PI) / 6), -300.0);
	// 240
	glVertex3f(19 *cos((4 * M_PI) / 3), 19 *sin((4 * M_PI) / 3), -300.0);
	glVertex3f(20 *cos((4 * M_PI) / 3), 20 *sin((4 * M_PI) / 3), -300.0);
	glVertex3f(29 *cos((4 * M_PI) / 3), 29 *sin((4 * M_PI) / 3), -300.0);
	glVertex3f(30 *cos((4 * M_PI) / 3), 30 *sin((4 * M_PI) / 3), -300.0);
	glVertex3f(39 *cos((4 * M_PI) / 3), 39 *sin((4 * M_PI) / 3), -300.0);
	glVertex3f(40 *cos((4 * M_PI) / 3), 40 *sin((4 * M_PI) / 3), -300.0);
	// 270
	glVertex3f(19 *cos((3 * M_PI) / 2), 19 *sin((3 * M_PI) / 2), -300.0);
	glVertex3f(20 *cos((3 * M_PI) / 2), 20 *sin((3 * M_PI) / 2), -300.0);
	glVertex3f(29 *cos((3 * M_PI) / 2), 29 *sin((3 * M_PI) / 2), -300.0);
	glVertex3f(30 *cos((3 * M_PI) / 2), 30 *sin((3 * M_PI) / 2), -300.0);
	glVertex3f(39 *cos((3 * M_PI) / 2), 39 *sin((3 * M_PI) / 2), -300.0);
	glVertex3f(40 *cos((3 * M_PI) / 2), 40 *sin((3 * M_PI) / 2), -300.0);
	// 300
	glVertex3f(19 *cos((5 * M_PI) / 3), 19 *sin((5 * M_PI) / 3), -300.0);
	glVertex3f(20 *cos((5 * M_PI) / 3), 20 *sin((5 * M_PI) / 3), -300.0);
	glVertex3f(29 *cos((5 * M_PI) / 3), 29 *sin((5 * M_PI) / 3), -300.0);
	glVertex3f(30 *cos((5 * M_PI) / 3), 30 *sin((5 * M_PI) / 3), -300.0);
	glVertex3f(39 *cos((5 * M_PI) / 3), 39 *sin((5 * M_PI) / 3), -300.0);
	glVertex3f(40 *cos((5 * M_PI) / 3), 40 *sin((5 * M_PI) / 3), -300.0);
	// 330
	glVertex3f(19 *cos((11 * M_PI) / 6), 19 *sin((11 * M_PI) / 6), -300.0);
	glVertex3f(20 *cos((11 * M_PI) / 6), 20 *sin((11 * M_PI) / 6), -300.0);
	glVertex3f(29 *cos((11 * M_PI) / 6), 29 *sin((11 * M_PI) / 6), -300.0);
	glVertex3f(30 *cos((11 * M_PI) / 6), 30 *sin((11 * M_PI) / 6), -300.0);
	glVertex3f(39 *cos((11 * M_PI) / 6), 39 *sin((11 * M_PI) / 6), -300.0);
	glVertex3f(40 *cos((11 * M_PI) / 6), 40 *sin((11 * M_PI) / 6), -300.0);

	glEnd();


	// fan outline circular shape
	glMatrixMode(GL_MODELVIEW);		// specify model view matrix
	glLoadIdentity();				// ensures fresh states
	glColor3f(0.5, 0.5, 0.0);		// dull yellow
	glBegin(GL_LINE_STRIP);																	// degrees
	glVertex3f(bladeScale*cos(0), bladeScale*sin(0), -300.0);								// 0
	glVertex3f(bladeScale*cos(M_PI / 6), bladeScale*sin(M_PI / 6), -300.0);					// 30
	glVertex3f(bladeScale*cos(M_PI / 3), bladeScale*sin(M_PI / 3), -300.0);					// 60
	glVertex3f(bladeScale*cos(M_PI / 2), bladeScale*sin(M_PI / 2), -300.0);					// 90
	glVertex3f(bladeScale*cos((2 * M_PI) / 3), bladeScale*sin((2 * M_PI) / 3), -300.0);		// 120
	glVertex3f(bladeScale*cos((5 * M_PI) / 6), bladeScale*sin((5 * M_PI) / 6), -300.0);		// 150
	glVertex3f(bladeScale*cos(M_PI), bladeScale*sin(M_PI), -300.0);							// 180
	glVertex3f(bladeScale*cos((7 * M_PI) / 6), bladeScale*sin((7 * M_PI) / 6), -300.0);		// 210
	glVertex3f(bladeScale*cos((4 * M_PI) / 3), bladeScale*sin((4 * M_PI) / 3), -300.0);		// 240
	glVertex3f(bladeScale*cos((3 * M_PI) / 2), bladeScale*sin((3 * M_PI) / 2), -300.0);		// 270
	glVertex3f(bladeScale*cos((5 * M_PI) / 3), bladeScale*sin((5 * M_PI) / 3), -300.0);		// 300
	glVertex3f(bladeScale*cos((11 * M_PI) / 6), bladeScale*sin((11 * M_PI) / 6), -300.0);	// 330
	glVertex3f(bladeScale*cos(0), bladeScale*sin(0), -300.0);								// 360
	glEnd();

	// food
	food();

	// fish
	// body
	// body uses glTranslate to move the fish body
	glMatrixMode(GL_MODELVIEW);		// specify model view matrix
	glLoadIdentity();				// ensures fresh states
	glColor3f(1.0, 0.55, 0.0);		// orange
	glTranslatef(fishx, fishy, -175.0);	// vars used to move fish around using glutKeyboardFunc
	glRotatef(0, 0, 0, 0);				// no rotation
	glScalef(37.5, 12.5, 12.5);			// scale body up
	glutWireOctahedron();				// draw body
	// tail
	glMatrixMode(GL_MODELVIEW);		// specify model view matrix
	glLoadIdentity();				// ensures fresh states
	glColor3f(1.0, 0.55, 0.0);		// orange
	// tail uses global variables to draw the movement of the fish tail
	// glVertex (fish x-offset + base x, fish y-offset + base y) 
	glBegin(GL_LINE_STRIP);
	glVertex3f(fishx + 37.5, fishy + 0.0,-175.0);	// base of body
	glVertex3f(fishx + 52.5, fishy + 12.5, -175.0);	// top edge
	glVertex3f(fishx + 52.5, fishy + -12.5, -175.0);// bottom edge
	glVertex3f(fishx + 37.5, fishy + 0.0, -175.0);	// base
	glEnd();

	// fish tank
	glMatrixMode(GL_MODELVIEW);		// specify model view matrix
	glLoadIdentity();				// ensures fresh states
	glTranslatef(0, 0, -175);		// z = -50 + (-125)		-125=center of cube		-50=front face z=-50
	//glScalef(250, 250, 250);		// cube edge length 250
	// draw shape
	glColor3f(1.0, 1.0, 0);			// bright yellow
	glutWireCube(250.0);			// wire cube

	//printf("foodx is %f\nfoody is %f\nfishx is %f\nfishy is %f\n\n", foodx, foody, fishx, fishy);

	glutSwapBuffers();		// swap buffers for double buffer
	glFlush();
}

// function to control food behaviors
void food()
{
	// run this as long as we have time remaining
	if (!gameOver)
	{
		// default conditional
		// draw food as normal
		if (visible == 1 && foodLifetime < 50)	// frames % 50 = every 4 seconds
		{
			glMatrixMode(GL_MODELVIEW);		// specify model view matrix
			glLoadIdentity();				// ensures fresh states
			glTranslatef(foodx, foody, -175);	// generates food at random position
			glColor3f(1, 1, 1);		// white
			glutSolidSphere(5.0, 12.0, 12.0);	// radius=5, slices=12, stacks=12
		}
		// conditional if food has been alive for more than 4 seconds uneaten
		else if (visible == 1 && foodLifetime > 50)
		{
			// relocate food after 4 seconds
			foodx = (rand() % 200) - 100;	// range = [-100, 100]
			foody = (rand() % 200) - 100;	// so we subtract 100 from range [0, 200]

			glMatrixMode(GL_MODELVIEW);		// specify model view matrix
			glLoadIdentity();				// ensures fresh states
			glTranslatef(foodx, foody, -175);	// generates food at random position
			glColor3f(1, 1, 1);		// white
			glutSolidSphere(5.0, 12.0, 12.0);	// radius=5, slices=12, stacks=12

			// fresh life time
			foodLifetime = 0;
		}
		// conditional if food has been eaten
		else if (visible == 0 && foodLifetime > 12)	// food has been gone for more than 1 second
		{
			glMatrixMode(GL_MODELVIEW);		// specify model view matrix
			glLoadIdentity();				// ensures fresh states
			glTranslatef(foodx, foody, -175);	// generates food at random position
			glColor3f(1, 1, 1);		// white
			glutSolidSphere(5.0, 12.0, 12.0);	// radius=5, slices=12, stacks=12

			// fresh life time
			foodLifetime = 0;
			visible = 1;
		}
	}
}

// timer listener to handle animation
void timer_func(int val)
{
	fanRotatePos++;	// increment the counter that is used to rotate the fan
	
	// distance formula
	distance = sqrt(pow(fishx - foodx, 2) + pow(fishy - foody, 2));

	// if fish center comes within 50 units of food center turn food color to black (invisible)
	// relocate immediatly if "eaten"
	if (distance <= 50)
	{
		visible = 0;	// set variable to invis
		foodx = (rand() % 200) - 100;	// range = [-100, 100]
		foody = (rand() % 200) - 100;	// so we subtract 100 from range [0, 200]
		foodLifetime = 0;	// used to measure how long food has been gone
		score = score + 10;
	}
	foodLifetime++;		// increment for every frame update
	elapsedFrames++;	// increment for timer

	// 12 frames roughly = 1 second at 12.5fps
	if (elapsedFrames % 12 == 0 && timer != 0)
	{
		timer--;	// take 1 second off timer
		//printf("Second Elapsed\n");
	}

	// out of time
	if (timer == 0)
	{
		gameOver = true;
		glutKeyboardFunc(NULL);	// take away keyboard control
	}

	display_func();
	glutTimerFunc(80, timer_func, 1); // called 80msecs later = about 12.5 calls per second
}

// function to handle keyboard movements for fish
// restrictions are in place to ensure the fish stays in the tank
void keyboard_func(unsigned char key, int x, int y)
{
	if (key == 'h' && fishx > -100)	// left
	{
		// increment fish x-position about the fish's center 10 units to the left
		fishx = fishx - 10;
	}
	if (key == 'j' && fishx < 80)	// right, use 80 to account for tail
	{
		// increment fish x-position about the fish's center 10 units to the right
		fishx = fishx + 10;
	}
	if (key == 'u' && fishy < 100)	// up
	{
		// increment fish x-position about the fish's center 10 units up
		fishy = fishy + 10;

	}
	if (key == 'n' && fishy > -100)	// down
	{
		// increment fish x-position about the fish's center 10 units down
		fishy = fishy - 10;
	}

}

// can customize the below 3 items to make canvas of ones own size and labeling
#define canvas_Width 640
#define canvas_Height 640
char canvas_Name[] = "Program 4 Nguyen";  // may need to modify to be a const char

int main(int argc, char ** argv)
{
	glutInit(&argc, argv);
	my_setup(canvas_Width, canvas_Height, canvas_Name);

	glutTimerFunc(80, timer_func, 1);	// about 12.5 calls per second
	glutKeyboardFunc(keyboard_func);
	glutDisplayFunc(display_func);

	glutMainLoop();
	return 0;
}