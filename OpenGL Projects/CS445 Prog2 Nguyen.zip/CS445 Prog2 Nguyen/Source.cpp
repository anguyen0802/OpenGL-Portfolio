// CS 445 Prog 2 for Anhkhoa Nguyen

// Architecture Statement:
// This code creates a game with the premise of controlling a character to dodge moving triangles and will keep going until the user fails to dodge 3 times, 
// in which case the game will exit. The game starts on a static screen (no animation) which is drawn by the display function called "display_func" using
// OpenGL primitives. The C shape is drawn by defining a display list called "drawC" then invoking the display list. Animation of the triangles is achieved
// by utilizing a timer function called "timer_func" which increments the global variable x_pos by an amount equal to the variable called "speed" then
// calling display_func to redraw the scene. Afterwards, it makes another timer event in 33msec to call itself again in order to continue the animation.
// The x_pos variable is added to each vertex's x value in the triangle shape in order to track the shift amount of the triangle. In each iteration of
// timer_func, we check if the triangle has collided with the player. If the triangle did collide with the player, speed is set to 0 and the triangle is
// stopped, waiting for the next cycle reset. If not, it continues onto the yellow barrier where the speed is set to 0, awaiting the next cycle. Cycle
// resets are controlled by another global variable called "elapsedFrames" that tracks each iteration of timer_func (each frame). After 105 frames
// (3.5 seconds at 30fps), the scene is reset to the next cycle. At the time of reset, timer_func will determine whether the triangle collided with the
// player or the yellow end zone and updates the trackers appropriately. If the player's lives are 0 a timer event is created after 3000msec to exit the
// program through the use of the functioned called "exit." Keyboard functionality is handled using glutKeyboardFunc to listen for keyboard inputs through 
// the initial function called "welcome." After the initial keyboard press, "welcome" makes a timed event call to the main timer function called "timer_func"
// to start the animation loop as well as relinquishing control of the keyboard listener to "keyboard_func" which holds the main purpose of listening for
// keyboard presses 'u' and 'n' to move the player character up and down respectively using the global variable y_pos. Each 'u' and 'n' press increments/decrements
// y_pos  respectively. The y value of each vertex in the player character shape is combined with the y_pos variable to track where the player is on the
// canvas on each given frame. If the player runs out of lives, glutKeyboardFunc is told to stop listening for keyboard events to stop the player from
// moving anymore while waiting for the program to exit.
#include "pch.h"
#include <GL/glew.h>
#include <GL/freeglut.h> 
#include "OpenGL445Setup.h"
#include <stdio.h>
#include <stdlib.h>

GLuint drawC; // id for drawing C display list
int x_pos = 0; // used for road sign
int y_pos = 0; // used for player position
bool started = false;
int score = 0;
int lives = 3;
int speed = (rand() % 5) + 5; // generates random number between 5 and 9

void display_func()
{
	// display callback (footnote: automatically invoked after GLUT finds that a window needs to be
	// displayed or redisplayed

	// black background, clear the canvas every time display_func is called
	glClearColor(1.0, 1.0, 1.0, 1.0);
	glClear(GL_COLOR_BUFFER_BIT);

	// display list to draw C shapped boundry, dimensions: 100 pixels tall and 30 pixels wide
	drawC = glGenLists(1);
	glNewList(drawC, GL_COMPILE);
	glColor3f(0.0, 0.0, 1.0);
	glBegin(GL_LINE_STRIP);
	glVertex3i(30, 200, -10);
	glVertex3i(15, 215, -10);
	glVertex3i(5, 225, -10);
	glVertex3i(1, 240, -10);
	glVertex3i(1, 260, -10);
	glVertex3i(5, 275, -10);
	glVertex3i(15, 285, -10);
	glVertex3i(30, 300, -10);
	glEnd();
	glEndList();
	// call the list
	glCallList(drawC);

	// x_pos+x to use x_pos as an incremental shift
	// triangle
	glColor3f(1.0, 0.0, 0.0);
	glBegin(GL_LINE_STRIP);
	glVertex3i(x_pos + 30, 265, -10);
	glVertex3i(x_pos + 70, 265, -10);
	glVertex3i(x_pos + 50, 235, -10);
	glVertex3i(x_pos + 30, 265, -10);
	glEnd();

	// draw yellow barrier on right of canvas
	glColor3f(0.80, 0.80, 0.0); // dark yellow
	glBegin(GL_LINES);
	glVertex3i(479, 140, -10);
	glVertex3i(479, 340, -10);
	glVertex3i(478, 140, -10);
	glVertex3i(478, 340, -10);
	glVertex3i(477, 140, -10);
	glVertex3i(477, 340, -10);
	glVertex3i(476, 340, -10);
	glVertex3i(476, 140, -10);
	glEnd();

	// player
	glColor3f(0.0, 0.6, 0.0); // dark green
	glBegin(GL_LINES);
	glVertex3i(380, y_pos + 275, -10);	// body
	glVertex3i(380, y_pos + 235, -10);	// body
	glVertex3i(380, y_pos + 235, -10);	// left leg
	glVertex3i(370, y_pos + 210, -10);	// left leg
	glVertex3i(380, y_pos + 235, -10);	// right leg
	glVertex3i(390, y_pos + 210, -10);	// right leg
	glVertex3i(380, y_pos + 265, -10);	// left arm
	glVertex3i(370, y_pos + 240, -10);	// left arm
	glVertex3i(380, y_pos + 265, -10);	// right arm
	glVertex3i(390, y_pos + 240, -10);	// right arm
	glVertex3i(375, y_pos + 275, -10);	// bottom head
	glVertex3i(385, y_pos + 275, -10);	// bottom head
	glVertex3i(385, y_pos + 275, -10);	// right head
	glVertex3i(385, y_pos + 285, -10);	// right head
	glVertex3i(375, y_pos + 285, -10);	// top head
	glVertex3i(385, y_pos + 285, -10);	// top head
	glVertex3i(375, y_pos + 275, -10);	// left head
	glVertex3i(375, y_pos + 285, -10);	// left head
	glEnd();

	// start message
	glColor3f(0.0, 0.0, 0.0);
	glRasterPos3f(150, 400, -10);
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, 'P');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, 'r');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, 'e');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, 's');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, 's');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, ' ');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, 'b');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, ' ');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, 'K');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, 'e');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, 'y');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, ' ');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, 'T');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, 'o');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, ' ');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, 'B');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, 'e');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, 'g');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, 'i');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, 'n');

	// score tracker
	glColor3f(0.0, 0.0, 0.0);
	glRasterPos3f(400, 450, -10);
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, 'S');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, 'c');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, 'o');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, 'r');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, 'e');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, ':');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, ' ');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, score + '0');

	// life tracker
	glColor3f(0.0, 0.0, 0.0);
	glRasterPos3f(25, 450, -10);
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, 'L');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, 'i');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, 'v');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, 'e');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, 's');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, ':');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, ' ');
	glutBitmapCharacter(GLUT_BITMAP_8_BY_13, lives + '0');
	glFlush();
}

// function to be called when game over
void exit()
{
	exit(0);
}

int elapsedFrames = 0;
// timer listener to handle animation
void timer_func(int val)
{
	// increment triangle's x position by 5 pixels each call
	x_pos = x_pos + speed;
	display_func();

	// reset if any of these conditions are met:
	// 1. triangle hits yellow barrier
	// 2. triangle reaches x_pos=300 (player barrier) and y_pos!=60 (player isn't above it)
	// 3. triangle reaches x_pos=300 (player barrier) and y_pos!=-50 (player isn't below it it)
	if (x_pos >= 300 && (y_pos < 60 && y_pos > -50)) // -50 < y_pos < 60  =  player hit
	{
		// stop movement
		speed = 0;
		//lives--;
	}
	if (x_pos >= 400)
	{
		// stop movement
		speed = 0;
		//score++;
	}

	// track elapsed frames
	elapsedFrames += 1;	// +30~ per second, 30 * 3.5 = 105
	// reset scene
	if (elapsedFrames >= 105) // every 105 frames (3.5 seconds)
	{
		// determine if life was lost or score +1
		if (x_pos >= 400) // if triangle made it to barrier
		{
			score++;

			// reset scene
			elapsedFrames = 0;
			x_pos = 0;
			y_pos = 0;
			speed = (rand() % 5) + 5; // next triangle random speed 5-9
			display_func(); // redraw scene
		}
		else if (x_pos >= 300 && (y_pos < 60 && y_pos > -50))
		{
			lives--;
			if (lives == 0)
			{
				glutKeyboardFunc(NULL); // stop listening for keyboard events
				glutTimerFunc(3000, exit, 1); // exits after 3 seconds
			}
			else // continue playing
			{
				elapsedFrames = 0;
				x_pos = 0;
				y_pos = 0;
				speed = (rand() % 5) + 5; // next triangle random speed 5-9
				display_func(); // redraw scene
			}
		}
	}

	// recall func
	if (lives != 0)
	{
		glutTimerFunc(33, timer_func, 1); // called 33msecs later = about 30fps
	}
}

void keyboard_func(unsigned char key, int x, int y)
{
	if (key == 'u')
	{
		y_pos += 10;
		//printf("u pressed\n");
	}
	if (key == 'n')
	{
		y_pos -= 10;
		//printf("n pressed\n");
	}
}
void welcome(unsigned char key, int x, int y)
{
	if (key == 'b')
	{
		glutTimerFunc(33, timer_func, 1);
		glutKeyboardFunc(keyboard_func); // listen on keyboard_func instead now
		//printf("b pressed\n");
	}
}


// can customize the below 3 items to make canvas of ones own size and labeling
#define canvas_Width 480
#define canvas_Height 480
char canvas_Name[] = "Program 1 Nguyen";  // may need to modify to be a const char

int main(int argc, char ** argv)
{
	glutInit(&argc, argv);
	my_setup(canvas_Width, canvas_Height, canvas_Name);

	glutKeyboardFunc(welcome);
	glutDisplayFunc(display_func);

	glutMainLoop();
	return 0;
}