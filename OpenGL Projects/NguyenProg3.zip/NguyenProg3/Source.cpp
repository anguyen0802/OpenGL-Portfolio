// CS 445 Prog 3 for Anhkhoa Nguyen
// EXTRA CREDIT: Spinning Diamond

// Architecture Statement:
//This program is a game where the user tries to navigate a falling diamond into the target landing zone. The game ends when either the diamond successfully reaches the landing zone,
//or the diamond misses the landing zone and hits the bottom. The falling animation is achieved through a timer function called timer_func that is calls itself every 80msec to achieve
//12.5 frame updates per second as well as calling the main glut display function to redraw the scene (display_func). The program starts by listening to keyboard inputs through the
//keyboard function called welcome. After the user starts the game by pressing the appropriate key, glut keyboard functions are now handled by a different keyboard function called
//keyboard_func. keyboard_func handles left, right, and up movement of the diamond through user inputs. Depending on whether the user starts the game by pressing M or E, the gravitation
//acceleration constant changes, resulting in differing falling animations. The drawing of the main animated object is handled through a function called drawDiamond() and is called every frame.

#include "pch.h"
#include <GL/glew.h>
#include <GL/freeglut.h> 
#include "OpenGL445Setup.h"
#include <stdio.h>
#include <stdlib.h>

int fuel = 200;
float x_offset = 0;				// tracks the offset from center screen in x direction
float y_pos = 465;				// tracks how fair down obj is, 465 starting pos
bool isEarth = true;			// flag to track moon or earth
float eConst = -32.0;				// gravity acceleration constant for Earth
float mConst = -5.3;				// gravity acceleration constant for Moon
float velocity = 0;				// current velocity of diamond
float uPresses = 0;				// variable to track how many times we pressed up
bool isDocked = false;
/***************************************
	Earth Gravity: 32px /sec /sec
	Moon Gravity: 8px /sec /sec
***************************************/
float elapsedFrames = 0.0;			// used for tracking elapsed frames to calculate y_pos, this var is float because math expression involves floats
bool started = false;		// flag used to clear the starting text on screen
float spin = -1.0;			// global variable used to spin the diamond (extra credit)

void drawDiamond();	// draw diamond prototype

void display_func()
{
	// display callback (footnote: automatically invoked after GLUT finds that a window needs to be
	// displayed or redisplayed

	// black background, clear the canvas every time display_func is called
	glClearColor(0.0, 0.0, 0.0, 1.0);
	glClear(GL_COLOR_BUFFER_BIT);

	// concatenate string text with fuel counter into one string to be printed using bitmap representation
	char buf[10];	// buffer to store "Fuel: xyz\n"
	snprintf(buf, 10, "Fuel: %d", fuel);	// puts fuel string into buffer, fuel string is now in buf
	
	// fuel tracker
	glColor3f(1.0, 1.0, 1.0);
	glLoadIdentity();
	glRasterPos3f(25, 450, -10);
	glutBitmapString(GLUT_BITMAP_8_BY_13, (UCHAR*)buf);	// writed concatenated string
	
	// Diamond Holder
	glColor3f(1.0, 0.5, 0.0);	// orange
	glLoadIdentity();			// ensures we are drawing at origin
	glBegin(GL_LINE_STRIP);
	glVertex3f(16.0, 1.0, -50.0);
	glVertex3f(90.0, 1.0, -50.0);
	glVertex3f(90.0, 31.0, -50.0);
	glVertex3f(65.0, 31.0, -50.0);
	glVertex3f(52.5, 18.5, -50.0);
	glVertex3f(40.0, 31.0, -50.0);
	glVertex3f(16.0, 31.0, -50.0);
	glVertex3f(16.0, 1.0, -50.0);
	glEnd();

	// draw diamond
	drawDiamond();

	// blue lines
	glColor3f(0.0, 0.0, 1.0);	// blue
	glLoadIdentity();
	glBegin(GL_LINES);
	glVertex3f(0.0, 8.0, -50.0);
	glVertex3f(15.0, 8.0, -50.0);
	glVertex3f(90.0, 8.0, -50.0);
	glVertex3f(480.0, 8.0, -50.0);
	glEnd();

	if (!started)	// print only on starting screen
	{
		// start instructions
		glColor3f(1.0, 1.0, 1.0);
		glLoadIdentity();
		glRasterPos3f(160, 400, -10);
		glutBitmapString(GLUT_BITMAP_8_BY_13, (UCHAR*)"Press E or M to Start");
	}

	glFlush();
}

void drawDiamond()
{
	if (isDocked == false)
	{
		// specify where shape will be drawn
		glMatrixMode(GL_MODELVIEW);		// specify model view matrix
		glLoadIdentity();				// ensures fresh states
		glTranslatef(x_offset + 240, y_pos, -50);	// top center
		glRotatef(spin * 145.0, 0, 1, 0);			// extra credit,	rotates 145 for every frame called
		glScalef(12.5, 12.5, 12.5);		// 25 long line segments; diamond is 25 units tall/wide/long in total
		// draw shape
		glColor3f(0.0, 0.9, 1.0);	// light blue
		glutWireOctahedron();

		spin++;	// go to next spin position
	}
	else if (isDocked == true)
	{
		// draw diamond in holder
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		glTranslatef(52.5, 31.0, -50);
		glRotatef(0, 0, 0, 0);
		glScalef(12.5, 12.5, 12.5);
		// draw shape
		glColor3f(0.0, 0.9, 1.0);
		glutWireOctahedron();

		// you win msg
		glColor3f(1.0, 1.0, 1.0);
		glLoadIdentity();
		glRasterPos3f(200, 400, -10);
		glutBitmapString(GLUT_BITMAP_8_BY_13, (UCHAR*)"YOU WIN");
	}
}

// timer listener to handle animation
void timer_func(int val)
{
	elapsedFrames = elapsedFrames + 1.0;	// have to pre-increment or else we end up multiplying by 0 on the first frame
	if (y_pos > 15)	// if diamond is not at the bottom
	{
		if (isEarth)
		{
			// velocity = -32 * seconds
			velocity = eConst * (elapsedFrames / 12.5);	// elapsedFrames / 12.5 = seconds	ie: 25 elapsed frames = 2 seconds

			// y_pos = initial_pos + velocity * (seconds) + (amount of times u was pressed * 5 pixels)
			y_pos = (465 + velocity * (elapsedFrames / 12.5)) + (uPresses * 5);	// 465 = initial position
		}
		else if (!isEarth)
		{
			// velocity = -8 * seconds
			velocity = mConst * (elapsedFrames / 12.5);	// elapsedFrames / 12.5 = seconds	ie: 25 elapsed frames = 2 seconds
			// y_pos = velocity * seconds
			y_pos = (465 + (velocity * (elapsedFrames / 12.5))) + (uPresses * 5);	// 465 = initial position
		}
	}
	else // if diamond is at the bottom
	{
		glutKeyboardFunc(NULL);	// take away keyboard control
	}

	// check if docked
	if (y_pos <= 28 && (x_offset <= -150.0 && x_offset >= -224.0))
	{
		isDocked = true;
		display_func();
	}
	else // continue animation
	{
		display_func();	// redraw scene
		glutTimerFunc(80, timer_func, 1); // called 80msecs later = about 12.5 calls per second
	}
}

void keyboard_func(unsigned char key, int x, int y)
{
	if (key == 'h')	// left
	{
		x_offset = x_offset - 4;
	}
	if (key == 'j')	// right
	{
		x_offset = x_offset + 4;
	}
	if (key == 'u') // up
	{
		if (fuel > 0)	// stop u presses if out of fuel
		{
			fuel = fuel - 5;
			uPresses++;	// used in y_pos formula
		}
	}
}
void welcome(unsigned char key, int x, int y)
{
	if (key == 'e')
	{
		isEarth = true;
		started = true;
		glutTimerFunc(80, timer_func, 1);
		glutKeyboardFunc(keyboard_func); // listen on keyboard_func instead now
	}
	if (key == 'm')
	{
		isEarth = false;
		started = true;
		glutTimerFunc(80, timer_func, 1);
		glutKeyboardFunc(keyboard_func); // listen on keyboard_func instead now
	}
}


// can customize the below 3 items to make canvas of ones own size and labeling
#define canvas_Width 480
#define canvas_Height 480
char canvas_Name[] = "Program 3 Nguyen";  // may need to modify to be a const char

int main(int argc, char ** argv)
{
	glutInit(&argc, argv);
	my_setup(canvas_Width, canvas_Height, canvas_Name);

	glutKeyboardFunc(welcome);
	glutDisplayFunc(display_func);

	glutMainLoop();
	return 0;
}