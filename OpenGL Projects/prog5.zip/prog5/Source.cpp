// CS 445 Prog 5 for Anhkhoa Nguyen

// Architecture Statement:
//This program is a 3d graphic depicting the letters UAH written out using 3d cubes. The program invokes functions that draw each individual letter giving it the proper material properties.
//The program then spins the whole set of 3 letters about a vertical line in the center of the letters depicted by a triangluar spindle. The display function named "display_Func" is
//responsible for drawing the spindle as well as calling dedicated functions "drawA" and "drawUH" to create the blocky letters. Functions "drawA" and "drawUH" invoke a function called
//drawCube() which takes 3 variables xyz to draw a cube after translating to the appropriate location to properly depict the letters. A timer function called "timer_func"is set at the
//start of the program that increments a variable that is responsible for the rotation of the letters. timer_func then calls the display_func to redraw the scene right before calling itself
//again 80ms later.

#include "pch.h"
#include <GL/glew.h>
#include <GL/freeglut.h> 
#include "OpenGL445Setup.h"
#include <stdio.h>

int rotateBy = 0;	// used to rotate logo by 4 degrees each timer call

// prototypes
void drawCube(float x, float y, float z);
void drawA();
void drawUH();

void display_func()
{
	// display callback (footnote: automatically invoked after GLUT finds that a window needs to be
	// displayed or  redisplayed

	// black background, clear the canvas every time display_func is called
	// GL_DEPTH_BUFFER_BIT is used to determine each pixel's z value and only draw the appropriate z value closest to the viewer (all others behind are not drawn)
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// light properties for entire scene
	GLfloat light_ambient[] = { 0.2, 0.2, 0.2, 1.0 };
	GLfloat light_diffuse[] = { 0.7, 0.7, 0.7, 1.0 };
	GLfloat light_specular[] = { 0.5, 0.5, 0.5, 1.0 };
	GLfloat light_position[] = {0.3, 0.3, 1.0, 0.0};

	glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
	glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);

	// enable phong illumination
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_DEPTH_TEST);
	
	// define spindle material properties (dull gray)
	GLfloat material_ambient_spindle[] = { 0.2, 0.2, 0.2, 1.0 };
	GLfloat material_diffuse_spindle[] = { 0.2, 0.2, 0.2, 1.0 };
	GLfloat material_specular_spindle[] = { 0.3, 0.3, 0.3, 1.0 };
	GLfloat material_shininess_spindle[] = { 1 };
	glMaterialfv(GL_FRONT, GL_AMBIENT, material_ambient_spindle);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, material_diffuse_spindle);
	glMaterialfv(GL_FRONT, GL_SPECULAR, material_specular_spindle);
	glMaterialfv(GL_FRONT, GL_SHININESS, material_shininess_spindle);
	// draw spindle
	glBegin(GL_TRIANGLES);
	glVertex3i(-25, 0, -400);	// left
	glVertex3i(25, 0, -400);	// right
	glVertex3i(0, 75, -400);	// middle
	glEnd();

	// call func to draw U and H
	drawUH();

	// call func to draw A
	drawA();

	glutSwapBuffers();	// swap buffers for double buffering
	glFlush();
}

// cube drawing function, takes 3 variables x, y, z to draw a cube of size 50 at the given coordinates
void drawCube(float x, float y, float z)
{
	glMatrixMode(GL_MODELVIEW);

	// make entire set of blocks rotate about line x=0, z=400
	// Mental Order:
	// 1. Translate(0, 0, 400)
	// 2. Rotate
	// 3. Translate back (0, 0, -400)
	// code order is reverse

	// save previous matrix states
	glPushMatrix();

	// do our algorithm
	glTranslatef(0.0, 0.0, -400.0);
	glRotatef(rotateBy * 4, 0, 1, 0);
	glTranslatef(0.0, 0.0, 400.0);

	// draw obj
	glTranslatef(x, y, z);
	glutSolidCube(50);

	// restore previous matrix states
	glPopMatrix();
}

// function dedicated to drawing the U and H letters by using the drawCube() function after making it's transformations to
// place individual blocks to form the letter
void drawUH()
{
	// define material properties for letters U and H
	// U and H are to be shiny silvery gray
	GLfloat material_ambient_gray[] = { 0.2, 0.2, 0.2, 1.0 };
	GLfloat material_diffuse_gray[] = { 0.6, 0.6, 0.6, 1.0 };
	GLfloat material_specular_gray[] = { 0.75, 0.75, 0.75, 1.0 };
	GLfloat material_shininess_gray[] = { 5 };

	glMaterialfv(GL_FRONT, GL_AMBIENT, material_ambient_gray);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, material_diffuse_gray);
	glMaterialfv(GL_FRONT, GL_SPECULAR, material_specular_gray);
	glMaterialfv(GL_FRONT, GL_SHININESS, material_shininess_gray);

	// draw U
	drawCube(-325.0, -175.0, -400.0);	// base
	drawCube(-275.0, -175.0, -400.0);	// base
	drawCube(-225.0, -175.0, -400.0);	// base
	drawCube(-175.0, -175.0, -400.0);	// base
	drawCube(-175.0, -125.0, -400.0);	// right
	drawCube(-175.0, -75.0, -400.0);	// right
	drawCube(-175.0, -25.0, -400.0);	// right
	drawCube(-325.0, -125.0, -400.0);	// left
	drawCube(-325.0, -75.0, -400.0);	// left
	drawCube(-325.0, -25.0, -400.0);	// left

	// draw H
	drawCube(325.0, -175.0, -400.0);	// base
	drawCube(275.0, -125.0, -400.0);	// middle
	drawCube(225.0, -125.0, -400.0);	// middle
	drawCube(175.0, -175.0, -400.0);	// base
	drawCube(175.0, -125.0, -400.0);	// left
	drawCube(175.0, -75.0, -400.0);		// left
	drawCube(175.0, -25.0, -400.0);		// left
	drawCube(325.0, -125.0, -400.0);	// right
	drawCube(325.0, -75.0, -400.0);		// right
	drawCube(325.0, -25.0, -400.0);		// right
}

// function dedicated to drawing the A letter by using the drawCube() function after making it's transformations to
// place individual blocks to form the letter
void drawA()
{
	// define material properties for letter A
	// A is to be light/medium blue
	GLfloat material_ambient_blue[] = { 0.1, 0.1, 0.4, 1.0 };
	GLfloat material_diffuse_blue[] = { 0.1, 0.1, 0.3, 1.0 };
	GLfloat material_specular_blue[] = { 0.1, 0.1, 0.3, 1.0 };
	GLfloat material_shininess_blue[] = { 2 };

	glMaterialfv(GL_FRONT, GL_AMBIENT, material_ambient_blue);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, material_diffuse_blue);
	glMaterialfv(GL_FRONT, GL_SPECULAR, material_specular_blue);
	glMaterialfv(GL_FRONT, GL_SHININESS, material_shininess_blue);

	// draw A
	drawCube(-75.0, -175.0, -400.0);	// base left
	drawCube(75.0, -175.0, -400.0);	// base right
	drawCube(-60.0, -125.0, -400.0);	// left 2
	drawCube(60.0, -125.0, -400.0);	// right 2
	drawCube(-45, -75.0, -400.0);	// left 3
	drawCube(45, -75.0, -400.0);	// right 3
	drawCube(-25, -25, -400.0);	// left 4
	drawCube(25, -25, -400.0);	// right 4
	drawCube(-25, -125.0, -400.0);	// middle left
	drawCube(25, -125.0, -400.0);	// middle right
}

// timer listener to handle animation
// this function increments the varaible rotateBy by 1 each call. This variable is then later multiplied by 4 to achieve rotation by 4 degrees per call
void timer_func(int val)
{
	rotateBy++;
	display_func();	// redraw the scene
	glutTimerFunc(80, timer_func, 1); // called 80msecs later = about 12.5 calls per second
}

// can customize the below 3 items to make canvas of ones own size and labeling
#define canvas_Width 800
#define canvas_Height 800
char canvas_Name[] = "Program 5 Nguyen";  // may need to modify to be a const char


int main(int argc, char ** argv)
{
	glutInit(&argc, argv);
	my_setup(canvas_Width, canvas_Height, canvas_Name);

	// enable flat shading
	glShadeModel(GL_FLAT);
	// local illumination for camera
	glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_TRUE);

	glutTimerFunc(80, timer_func, 1);	// about 12.5 calls per second
	glutDisplayFunc(display_func);
	glutMainLoop();
	return 0;
}