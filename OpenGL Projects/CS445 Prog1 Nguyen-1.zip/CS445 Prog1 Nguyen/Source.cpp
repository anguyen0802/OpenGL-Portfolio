// CS 445 Prog 1 for Anhkhoa Nguyen
// EXTRA CREDIT: Letter Y inside the road sign

// Architecture Statement:
// This code achieves animation based on a timer handler to increment an integer (x_pos) by 5 pixels. This variable is used to represent the amount of pixels needed to 
// horizontally offset the three red triangles every given 66msec. Every shape is drawn in the display_func. The yellow barrier on the right is drawn as a boundry for
// the triangles to stop when they touch it. The function timer_func is the function that handles the timer event which is queued every 66 msec (to achieve 16fps). The 
// timer_func also checks to see if the triangle has hit a specific x_pos to know when to stop. Otherwise, timer_func calls itself again to create another timer event
// 66 msec later while also incrementing x_pos and calling the display_func once again to update the frame. The program also reads any standard input to start drawing 
// the initial frame and call the initial timer event to start the animation process, otherwise the program waits and does nothing.
#include "pch.h"
#include <GL/glew.h>
#include <GL/freeglut.h> 
#include "OpenGL445Setup.h"
#include <stdio.h>

int x_pos = 0;

void display_func()
{
	// display callback (footnote: automatically invoked after GLUT finds that a window needs to be
	// displayed or  redisplayed

	// black background, clear the canvas every time display_func is called
	glClearColor(0.0, 0.0, 0.0, 1.0);
	glClear(GL_COLOR_BUFFER_BIT);

	// draw C shapped boundry, dimensions: 100 pixels tall and 30 pixels wide
	glColor3f(0.0, 1.0, 0.0);
	glBegin(GL_LINE_STRIP);
	glVertex2i(30, 210);
	glVertex2i(15, 215);
	glVertex2i(10, 220);
	glVertex2i(1, 240);	// drawn on pixel x=1 instead of x=0 so it shows up on canvas
	glVertex2i(1, 260);
	glVertex2i(10, 280);
	glVertex2i(15, 285);
	glVertex2i(30, 290);
	glEnd();

	// draw three red triangles but using gl_line instead of gl_triangle
	// x_pos+x to use x_pos as an incremental shift
	// triangle 1
	glColor3f(1.0, 0.0, 0.0);
	glBegin(GL_LINE_STRIP);
	glVertex2i(x_pos + 20, 280);
	glVertex2i(x_pos + 60, 280);
	glVertex2i(x_pos + 40, 250);
	glVertex2i(x_pos + 20, 280);
	glEnd();
	// Y letter 1
	glColor3f(1.0, 0.0, 0.0);
	glBegin(GL_LINES);
	glVertex2i(x_pos + 35, 275);
	glVertex2i(x_pos + 40, 265);
	glVertex2i(x_pos + 45, 275);
	glVertex2i(x_pos + 40, 265);
	glVertex2i(x_pos + 40, 265);
	glVertex2i(x_pos + 40, 260);
	glEnd();

	// triangle 2
	glColor3f(1.0, 0.0, 0.0);
	glBegin(GL_LINE_STRIP);
	glVertex2i(x_pos + 60, 265);
	glVertex2i(x_pos + 100, 265);
	glVertex2i(x_pos + 80, 235);
	glVertex2i(x_pos + 60, 265);
	glEnd();
	// Y letter 2
	glColor3f(1.0, 0.0, 0.0);
	glBegin(GL_LINES);
	glVertex2i(x_pos + 75, 260);
	glVertex2i(x_pos + 80, 250);
	glVertex2i(x_pos + 85, 260);
	glVertex2i(x_pos + 80, 250);
	glVertex2i(x_pos + 80, 250);
	glVertex2i(x_pos + 80, 245);
	glEnd();

	// triangle 3
	glColor3f(1.0, 0.0, 0.0);
	glBegin(GL_LINE_STRIP);
	glVertex2i(x_pos + 20, 245);
	glVertex2i(x_pos + 60, 245);
	glVertex2i(x_pos + 40, 215);
	glVertex2i(x_pos + 20, 245);
	glEnd();
	// Y letter 3
	glColor3f(1.0, 0.0, 0.0);
	glBegin(GL_LINES);
	glVertex2i(x_pos + 35, 240);
	glVertex2i(x_pos + 40, 230);
	glVertex2i(x_pos + 45, 240);
	glVertex2i(x_pos + 40, 230);
	glVertex2i(x_pos + 40, 230);
	glVertex2i(x_pos + 40, 225);
	glEnd();

	// draw yellow barrier on right of canvas
	glColor3f(1.0, 1.0, 0.0);
	glBegin(GL_LINES);
	glVertex2i(479, 140);
	glVertex2i(479, 345);
	glVertex2i(478, 140);
	glVertex2i(478, 345);
	glVertex2i(477, 140);
	glVertex2i(477, 345);
	glVertex2i(476, 345);
	glVertex2i(476, 140);
	glEnd();

	glFlush();
}

// timer listener to handle animation
void timer_func(int val)
{
	// increment triangle's x position by 5 pixels each call
	x_pos = x_pos + 5;
	display_func();

	if (x_pos <= 370) // go until the right most triangle hits the yellow barrier
	{
		glutTimerFunc(66, timer_func, 1); // para1=66 for 16fps
	}
}

// can customize the below 3 items to make canvas of ones own size and labeling
#define canvas_Width 480
#define canvas_Height 480
char canvas_Name[] = "Program 1 Nguyen";  // may need to modify to be a const char


int main(int argc, char ** argv)
{
	glutInit(&argc, argv);
	my_setup(canvas_Width, canvas_Height, canvas_Name);
	char input;
	printf("Any key press will start\n");
	scanf_s("%c", &input);

	glutTimerFunc(66, timer_func, 1);
	//glutKeyboardFunc(keyboard_func);
	glutDisplayFunc(display_func);

	glutMainLoop();
	return 0;
}